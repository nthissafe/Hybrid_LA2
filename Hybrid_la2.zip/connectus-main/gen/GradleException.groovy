class GradleException {
    GradleException(String s) {

    }
}
